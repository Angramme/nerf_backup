import os
import logging as log
from typing import Tuple
from tqdm import tqdm
import numpy as np
import torch
import torch.nn as nn
from PIL import Image
import trimesh
import mcubes
import wandb
from scipy.ndimage import gaussian_filter

from .ray import exponential_integration
from .realnvp import RealNVP
from ..utils.metrics import psnr

# Warning: you MUST NOT change the resolution of marching cube
RES = 256

def generate_deltas(ts: torch.Tensor):
    """Calculates the difference between each 'time' in ray samples.

    Rays will go to infinity unless obstructed. Therefore, the delta
    between the ts and infinity is expressed as 1e10

    Args:
        ts: [B x N x num_samples x 1] tensor of times. The values are increasing from [near,far] along
            the num_samples dimension.
    Returns:
        deltas: [B x N x num_samples x 1]  where delta_i = t_i+1 - t_i.
    """
    B, N, _, _ = ts.shape
    deltas = torch.cat([ts[:, :, 1:, :] - ts[:, :, :-1, :], torch.full((B, N, 1, 1), 1e10, device=ts.device)], dim=2)
    return deltas

def inverse_transform_sampling(ray_orig: torch.Tensor, ray_dir: torch.Tensor, weights, ts,
                               num_points: int=128, near=1.0, far=3.0):
    """Performs inverse transform sampling according to the weights.

    Samples from ts according to the weights (i.e. ts with higher weights are 
    more likely to be sampled).
    
    Probably not the best implementation, since the official NeRF implementation 
    does something different. This is probably good enough though? Good thing
    I don't have to be rigorous. 

    Args:
        ray_orig: [B x N x 3] coordinates of the ray origin.
        ray_dir: [B x N x 3] directions of the ray.
        weights: [B x N x C x 1] tensor of weights calculated as 
                 w = T(1 - exp(- density * delta)). N is the batch size, and C 
                 is the number of coarse samples.
        ts: [B x N x C x 1] is the increment between each sample. N is the batch 
            size, and C is the number of coarse samples. 
        num_points: number of samples to return per ray.
        near/far: near/far bounds for sampling. 
    Returns:
        fine_samples: [B x N x num_points x 3] tensor sampled according to weights.
                      Instead of using the same values as in ts, we pertube it by 
                      adding random noise (sampled from U(0, 1/num_points)).
        fine_ts: [B x N x num_points x 1] tensor of the time increment for each sample. 
    """
    device = ray_orig.device
    B, N, C, _ = ts.shape

    cdf = torch.cumsum(weights, axis=2)  # [B x N x C x 1]
    cdf = cdf / cdf[:, -1, None]
    eps = torch.rand((N, 1), device=device) / num_points  # low variance sampling
    samples = torch.arange(0, 1, 1 / num_points, device=device)
    samples = torch.broadcast_to(samples, (B, N, num_points))
    samples = samples + eps
    cdf = torch.squeeze(cdf, -1)  # make dimensions match, [B x N x C]
    lower_idxs = torch.searchsorted(cdf, samples).unsqueeze(-1)  # [B x N x C x 1]
    upper_idxs = lower_idxs + 1

    lower = torch.full((B, N, 1, 1), near, device=device)
    upper = torch.full((B, N, 1, 1), far, device=device)
    ts_bounds = torch.cat([lower, ts, upper], dim=2)

    lower_bins = torch.gather(ts_bounds, 2, lower_idxs)
    upper_bins = torch.gather(ts_bounds, 2, upper_idxs)

    fine_ts = lower_bins + (upper_bins - lower_bins) * torch.rand((B, N, num_points, 1), device=device)
    fine_samples = ray_orig.unsqueeze(2) + fine_ts * ray_dir.unsqueeze(2)
    
    # Combine coarse and fine samples
    coarse_coords = ray_orig.unsqueeze(2) + ts * ray_dir.unsqueeze(2)
    fine_coords = torch.cat([fine_samples, coarse_coords], dim=2)
    fine_z_vals = torch.cat([fine_ts, ts], dim=2)
    fine_z_vals, idxs = torch.sort(fine_z_vals, dim=2)
    fine_coords = torch.gather(fine_coords, 2, idxs.expand(-1, -1, -1, 3))
    fine_deltas = generate_deltas(fine_z_vals)
    
    return fine_coords, fine_z_vals, fine_deltas

def lift_gaussian(d, t_mean, t_var, r_var, diag):
    mean = d[..., None, :] * t_mean[..., None]
    d_mag_sq = torch.sum(d ** 2, dim=-1, keepdim=True) + 1e-10

    if diag:
        d_outer_diag = d ** 2
        null_outer_diag = 1 - d_outer_diag / d_mag_sq
        t_cov_diag = t_var[..., None] * d_outer_diag[..., None, :]
        xy_cov_diag = r_var[..., None] * null_outer_diag[..., None, :]
        cov_diag = t_cov_diag + xy_cov_diag
        return mean, cov_diag
    else:
        d_outer = d[..., :, None] * d[..., None, :]
        eye = torch.eye(d.shape[-1], device=d.device)
        null_outer = eye - d[..., :, None] * (d / d_mag_sq)[..., None, :]
        t_cov = t_var[..., None, None] * d_outer[..., None, :, :]
        xy_cov = r_var[..., None, None] * null_outer[..., None, :, :]
        cov = t_cov + xy_cov
        return mean, cov

def conical_frustum_to_gaussian(d, t0, t1, base_radius, diag, stable=True):
    if stable:
        mu = (t0 + t1) / 2
        hw = (t1 - t0) / 2
        t_mean = mu + (2 * mu * hw**2) / (3 * mu**2 + hw**2)
        t_var = (hw**2) / 3 - (4 / 15) * ((hw**4 * (12 * mu**2 - hw**2)) / (3 * mu**2 + hw**2)**2)
        r_var = base_radius**2 * ((mu**2) / 4 + (5 / 12) * hw**2 - 4 / 15 * (hw**4) / (3 * mu**2 + hw**2))
    else:
        t_mean = (3 * (t1**4 - t0**4)) / (4 * (t1**3 - t0**3))
        r_var = base_radius**2 * (3 / 20 * (t1**5 - t0**5) / (t1**3 - t0**3))
        t_mosq = 3 / 5 * (t1**5 - t0**5) / (t1**3 - t0**3)
        t_var = t_mosq - t_mean**2
    return lift_gaussian(d, t_mean, t_var, r_var, diag)

def cylinder_to_gaussian(d, t0, t1, radius, diag):
    """Approximate a cylinder as a Gaussian distribution (mean+cov).

    Assumes the ray is originating from the origin, and radius is the
    radius. Does not renormalize `d`.

    Args:
      d: torch.float32 3-vector, the axis of the cylinder
      t0: float, the starting distance of the cylinder.
      t1: float, the ending distance of the cylinder.
      radius: float, the radius of the cylinder
      diag: boolean, whether or the Gaussian will be diagonal or full-covariance.

    Returns:
      a Gaussian (mean and covariance).
    """
    t_mean = (t0 + t1) / 2
    r_var = radius ** 2 / 4
    t_var = (t1 - t0) ** 2 / 12
    return lift_gaussian(d, t_mean, t_var, r_var, diag)

def cast_rays(t_vals, origins, directions, radii, ray_shape, diag=True):
    t0 = t_vals[..., :-1]
    t1 = t_vals[..., 1:]
    if ray_shape == 'cone':
        gaussian_fn = conical_frustum_to_gaussian
    elif ray_shape == 'cylinder':
        gaussian_fn = cylinder_to_gaussian
    else:
        assert False
    means, covs = gaussian_fn(directions, t0, t1, radii, diag)
    means = means + origins[..., None, :]
    return means, covs

class Trainer(nn.Module):

    def __init__(self, config, coarse_model, fine_model, pe, log_dir):
        super().__init__()

        self.cfg = config
        self.pos_enc = pe.cuda()
        self.coarse_model = coarse_model.cuda()
        self.fine_model = fine_model.cuda()
        
        self.log_dir = log_dir
        self.log_dict = {}

        self.init_optimizer()
        self.init_log_dict()

    def init_optimizer(self):
        self.optimizer = torch.optim.Adam(self.parameters(), lr=self.cfg.lr, 
                                    betas=(self.cfg.beta1, self.cfg.beta2),
                                    weight_decay=self.cfg.weight_decay)

    def init_log_dict(self):
        """Custom log dict.
        """
        self.log_dict['total_loss'] = 0.0
        self.log_dict['rgb_loss'] = 0.0
        self.log_dict['total_iter_count'] = 0
        self.log_dict['image_count'] = 0

    def sample_points(self, ray_orig, ray_dir, radii, near=1.0, far=3.0, num_points=64, ray_shape='cone'):
        B, Nr = ray_orig.shape[:2]
        t_vals = torch.linspace(0.0, 1.0, num_points + 1, device=ray_orig.device)
        z_vals = near * (1.0 - t_vals) + far * t_vals
        z_vals = z_vals.expand([B, Nr, num_points + 1])

        means, covs = cast_rays(z_vals, ray_orig, ray_dir, radii, ray_shape)
        return means, covs, z_vals[..., :-1], z_vals[..., 1:]

    def predict_radience(self, pos_enc_mean, pos_enc_cov, model=None):
        if model is None:
            model = self.fine_model

        input_shape = pos_enc_mean.shape
        pos_enc_mean = pos_enc_mean.view(-1, pos_enc_mean.shape[-1])
        pos_enc_cov = pos_enc_cov.view(-1, pos_enc_cov.shape[-1])

        pred = model(pos_enc_mean)
        rgb = torch.sigmoid(pred[..., :3])
        sigma = torch.relu(pred[..., 3:])

        return rgb.view(*input_shape[:-1], 3), sigma.view(*input_shape[:-1], 1)

    def volume_render(self, rgb, sigma, depth, deltas):
        """Ray marching to compute the radiance at the given rays.
        TODO: You are free to try out different neural rendering methods.
        
        Args:
            rgb (torch.FloatTensor): Radiance at the sampled points of shape [B, Nr, Np, 3].
            sigma (torch.FloatTensor): Volume density at the sampled points of shape [B, Nr, Np, 1].
            deltas (torch.FloatTensor): Distance between the points of shape [B, Nr, Np, 1].
        
        Returns:
            ray_colors (torch.FloatTensor): Radiance at the given rays of shape [B, Nr, 3].
            weights (torch.FloatTensor): Weights of the given rays of shape [B, Nr, 1].

        """
        # Sample points along the rays

        tau = sigma * deltas
        ray_colors, ray_dapth, ray_alpha, weights = exponential_integration(rgb, tau, depth, exclusive=True)

        return ray_colors, ray_dapth, ray_alpha, weights

    def forward(self):
        B, Nr = self.ray_orig.shape[:2]

        means, covs, t0, t1 = self.sample_points(
            self.ray_orig, self.ray_dir, self.radii, near=self.cfg.near, far=self.cfg.far,
            num_points=self.cfg.num_pts_per_ray, ray_shape=self.cfg.ray_shape)

        pos_enc_mean, pos_enc_cov = self.pos_enc(means, covs)

        rgb, sigma = self.predict_radience(pos_enc_mean, pos_enc_cov, model=self.coarse_model)
        ray_colors, ray_depth, ray_alpha, _ = self.volume_render(rgb, sigma, t0, t1 - t0)

        self.coarse_rgb = ray_colors

        fine_means, fine_covs, fine_t0, fine_t1 = self.sample_points(
            self.ray_orig, self.ray_dir, self.radii, near=self.cfg.near, far=self.cfg.far,
            num_points=self.cfg.num_pts_per_ray_render, ray_shape=self.cfg.ray_shape)

        fine_pos_enc_mean, fine_pos_enc_cov = self.pos_enc(fine_means, fine_covs)

        rgb, sigma = self.predict_radience(fine_pos_enc_mean, fine_pos_enc_cov, model=self.fine_model)
        ray_colors, ray_depth, ray_alpha, _ = self.volume_render(rgb, sigma, fine_t0, fine_t1 - fine_t0)

        if self.cfg.bg_color == 'white':
            bg = torch.ones(B, Nr, 3, device=ray_colors.device)
            self.fine_rgb = (1 - ray_alpha) * bg + ray_alpha * ray_colors
        else:
            self.fine_rgb = ray_alpha * ray_colors

    def backward(self):
        """Backward pass of the network.
        TODO: You can also desgin your own loss function.
        """

        loss = 0.0
        # rgb_loss = torch.abs(self.rgb -  self.img_gts).mean()
        # loss = rgb_loss # + any other loss terms
        fine_loss = nn.functional.mse_loss(self.fine_rgb, self.img_gts)
        coarse_loss = nn.functional.mse_loss(self.coarse_rgb, self.img_gts)
        rgb_loss = coarse_loss + fine_loss
        loss = rgb_loss

        self.log_dict['rgb_loss'] += rgb_loss.item()
        self.log_dict['total_loss'] += loss.item()

        loss.backward()

    def step(self, data):
        """A signle training step.
        """

        # Get rays, and put them on the device
        self.ray_orig = data['rays'][..., :3].cuda()
        self.ray_dir = data['rays'][..., 3:].cuda()
        self.img_gts = data['imgs'].cuda()

        self.optimizer.zero_grad()

        self.forward()
        self.backward()

        self.optimizer.step()
        self.log_dict['total_iter_count'] += 1
        self.log_dict['image_count'] += self.ray_orig.shape[0]

    def render(self, ray_orig, ray_dir):
        """Render a full image for evaluation.
        """
        B, Nr = ray_orig.shape[:2]
        coords, depth, deltas, _ = self.sample_points(ray_orig, ray_dir, near=self.cfg.near, far=self.cfg.far,
                                num_points=self.cfg.num_pts_per_ray_render)
        rgb, sigma = self.predict_radience(coords)
        ray_colors, ray_depth, ray_alpha, _ = self.volume_render(rgb, sigma, depth, deltas)

        if self.cfg.bg_color == 'white':
            bg = torch.ones(B, Nr, 3, device=ray_colors.device)
            render_img = (1 - ray_alpha) * bg + ray_alpha * ray_colors
        else:
            render_img = ray_alpha * ray_colors

        return render_img, ray_depth, ray_alpha

    def reconstruct_3D(self, save_dir, epoch=0, sigma_threshold = 50., chunk_size=8192, smoothing_sigma=1.0):
        """Reconstruct the 3D shape from the volume density.
        """

        # Mesh evaluation
        window_x = torch.linspace(-1., 1., steps=RES, device='cuda')
        window_y = torch.linspace(-1., 1., steps=RES, device='cuda')
        window_z = torch.linspace(-1., 1., steps=RES, device='cuda')
        
        coord = torch.stack(torch.meshgrid(window_x, window_y, window_z)).permute(1, 2, 3, 0).reshape(-1, 3).contiguous()

        _points = torch.split(coord, int(chunk_size), dim=0)
        voxels = []
        for _p in _points:
            _, sigma = self.predict_radience(_p) 
            voxels.append(sigma)
        voxels = torch.cat(voxels, dim=0)

        np_sigma = torch.clip(voxels, 0.0).reshape(RES, RES, RES).cpu().numpy()

        # Apply Gaussian smoothing
        # np_sigma_smoothed = gaussian_filter(np_sigma, sigma=smoothing_sigma)

        vertices, faces = mcubes.marching_cubes(np_sigma, sigma_threshold)
        #vertices = ((vertices - 0.5) / (res/2)) - 1.0
        vertices = (vertices / (RES-1)) * 2.0 - 1.0

        h = trimesh.Trimesh(vertices=vertices, faces=faces)
        h.export(os.path.join(save_dir, '%04d.obj' % (epoch)))

    def log(self, step, epoch):
        """Log the training information.
        """
        log_text = 'STEP {} - EPOCH {}/{}'.format(step, epoch, self.cfg.epochs)
        self.log_dict['total_loss'] /= self.log_dict['total_iter_count']
        log_text += ' | total loss: {:>.3E}'.format(self.log_dict['total_loss'])
        self.log_dict['rgb_loss'] /= self.log_dict['total_iter_count']
        log_text += ' | rgb loss: {:>.3E}'.format(self.log_dict['rgb_loss'])

        log.info(log_text)

        for key, value in self.log_dict.items():
            if 'loss' in key:
                wandb.log({key: value}, step=step)
        self.init_log_dict()

    def validate(self, loader, img_shape, step=0, epoch=0, sigma_threshold = 50., chunk_size=8192, save_img=False):
        """validation function for generating final results.
        """
        torch.cuda.empty_cache() # To avoid CUDA out of memory
        self.eval()

        log.info("Beginning validation...")
        log.info(f"Loaded validation dataset with {len(loader)} images at resolution {img_shape[0]}x{img_shape[1]}")


        self.valid_mesh_dir = os.path.join(self.log_dir, "mesh")
        log.info(f"Saving reconstruction result to {self.valid_mesh_dir}")
        if not os.path.exists(self.valid_mesh_dir):
            os.makedirs(self.valid_mesh_dir)

        if save_img:
            self.valid_img_dir = os.path.join(self.log_dir, "img")
            log.info(f"Saving rendering result to {self.valid_img_dir}")
            if not os.path.exists(self.valid_img_dir):
                os.makedirs(self.valid_img_dir)

        psnr_total = 0.0

        wandb_img = []
        wandb_img_gt = []

        with torch.no_grad():
            # Evaluate 3D reconstruction
            self.reconstruct_3D(self.valid_mesh_dir, epoch=epoch,
                            sigma_threshold=sigma_threshold, chunk_size=chunk_size)

            # Evaluate 2D novel view rendering
            for i, data in enumerate(tqdm(loader)):
                rays = data['rays'].cuda()          # [1, Nr, 6]
                img_gt = data['imgs'].cuda()        # [1, Nr, 3]
                mask = data['masks'].repeat(1, 1, 3).cuda()

                _rays = torch.split(rays, int(chunk_size), dim=1)
                pixels = []
                for _r in _rays:
                    ray_orig = _r[..., :3]          # [1, chunk, 3]
                    ray_dir = _r[..., 3:]           # [1, chunk, 3]
                    ray_rgb, ray_depth, ray_alpha = self.render(ray_orig, ray_dir)
                    pixels.append(ray_rgb)

                pixels = torch.cat(pixels, dim=1)

                psnr_total += psnr(pixels, img_gt)

                img = (pixels).reshape(*img_shape, 3).cpu().numpy() * 255
                gt = (img_gt).reshape(*img_shape, 3).cpu().numpy() * 255
                wandb_img.append(wandb.Image(img))
                wandb_img_gt.append(wandb.Image(gt))

                if save_img:
                    Image.fromarray(gt.astype(np.uint8)).save(
                        os.path.join(self.valid_img_dir, "gt-{:04d}-{:03d}.png".format(epoch, i)) )
                    Image.fromarray(img.astype(np.uint8)).save(
                        os.path.join(self.valid_img_dir, "img-{:04d}-{:03d}.png".format(epoch, i)) )

        wandb.log({"Rendered Images": wandb_img}, step=step)
        wandb.log({"Ground-truth Images": wandb_img_gt}, step=step)
                
        psnr_total /= len(loader)

        log_text = 'EPOCH {}/{}'.format(epoch, self.cfg.epochs)
        log_text += ' {} | {:.2f}'.format(f"PSNR", psnr_total)

        wandb.log({'PSNR': psnr_total, 'Epoch': epoch}, step=step)
        log.info(log_text)
        self.train()

    def save_model(self, epoch):
        """Save the model checkpoint.
        """

        fname = os.path.join(self.log_dir, f'model-{epoch}.pth')
        log.info(f'Saving model checkpoint to: {fname}')
        torch.save(self.fine_model, fname)
